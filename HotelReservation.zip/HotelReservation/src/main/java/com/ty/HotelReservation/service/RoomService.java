package com.ty.HotelReservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.HotelReservation.dao.RoomDao;
import com.ty.HotelReservation.dto.Rooms;
import com.ty.HotelReservation.dto.Users;
import com.ty.HotelReservation.exception.DetailsNotFoundException;
import com.ty.HotelReservation.util.ResponseStructure;

@Service
public class RoomService {

	@Autowired
	RoomDao roomDao;

	public ResponseEntity<ResponseStructure<Rooms>> saveRooms(Rooms rooms){
		Rooms room = roomDao.saveRooms(rooms);
		ResponseStructure<Rooms> structure = new ResponseStructure<Rooms>();
		structure.setMessage("Data Saved Successfully");
		structure.setHttpStatus(HttpStatus.CREATED.value());
		structure.setData(room);
		return new ResponseEntity<ResponseStructure<Rooms>>(structure,HttpStatus.CREATED);

	}
	public ResponseEntity<ResponseStructure<Rooms>> getAllRooms(){
		List<Rooms> rooms = roomDao.getAllRooms();
		ResponseStructure<Rooms> structure = new ResponseStructure<Rooms>();
		structure.setMessage("Data Fetched Successfully");
		structure.setHttpStatus(HttpStatus.FOUND.value());
		structure.setData(rooms);
		return new ResponseEntity<ResponseStructure<Rooms>>(structure,HttpStatus.FOUND);
	}

	public ResponseEntity<ResponseStructure<Rooms>> getRoomsById(int id){
		Rooms rooms = roomDao.getRoomsById(id);
		if (rooms!=null) {

			ResponseStructure<Rooms> structure = new ResponseStructure<Rooms>();
			structure.setMessage("Data Fetched Successfully");
			structure.setHttpStatus(HttpStatus.FOUND.value());
			structure.setData(rooms);
			return new ResponseEntity<ResponseStructure<Rooms>>(structure,HttpStatus.FOUND);

		}
		else {
			throw new DetailsNotFoundException("Failed to load data");
		}
	}

	public ResponseEntity<ResponseStructure<Rooms>> updateRooms(int id, Rooms rooms){
		Rooms roomss = roomDao.updateRoom(id, rooms);
		if (roomss != null) {
			ResponseStructure<Rooms> structure = new ResponseStructure<Rooms>();
			structure.setMessage("Data Updated successfully");
			structure.setHttpStatus(HttpStatus.OK.value());
			structure.setData(roomss);
			return new ResponseEntity<ResponseStructure<Rooms>>(structure, HttpStatus.OK);
		} else {
			throw new DetailsNotFoundException("Sorry failed to Update the data");

		}
	}
	public ResponseEntity<ResponseStructure<Rooms>> reserveRoom(int roomId, int userId)
	{
		Rooms room = roomDao.reserveRoom(roomId, userId);
		if (room != null) {
			ResponseStructure<Rooms> structure = new ResponseStructure<Rooms>();
			structure.setMessage("Room Reserved successfully");
			structure.setHttpStatus(HttpStatus.OK.value());
			structure.setData(room);
			return new ResponseEntity<ResponseStructure<Rooms>>(structure, HttpStatus.OK);
		} else {
			throw new DetailsNotFoundException("Sorry failed to Update the data");

		}

	}
	public ResponseEntity<ResponseStructure<Rooms>> VacateRoom(int roomId)
	{
		Rooms room = roomDao.vacateRoom(roomId);
		if (room !=null) {
			ResponseStructure<Rooms> structure = new ResponseStructure<Rooms>();
			structure.setMessage("Room vacated successfully");
			structure.setHttpStatus(HttpStatus.OK.value());
			structure.setData(room);
			return new ResponseEntity<ResponseStructure<Rooms>>(structure, HttpStatus.OK);
		} else {
			throw new DetailsNotFoundException("Sorry failed to Update the data");

		}

	}


}


