package com.ty.HotelReservation.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
public class Users {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY,generator = "user_id")
	@SequenceGenerator(name = "user_id",initialValue = 201,allocationSize = 1)
	private int id;
	private String userName;
	private String password;
}
