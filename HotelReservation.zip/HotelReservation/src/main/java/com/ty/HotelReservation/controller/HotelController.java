package com.ty.HotelReservation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ty.HotelReservation.dto.Hotels;
import com.ty.HotelReservation.service.HotelService;
import com.ty.HotelReservation.util.ResponseStructure;
import org.springframework.web.bind.annotation.PutMapping;



@RestController
public class HotelController {
	@Autowired
	HotelService hotelService;
	
	@PostMapping("/hotels")
	public ResponseEntity<ResponseStructure<Hotels>> saveHotels(@RequestBody Hotels hotel){
		return hotelService.saveHotel(hotel);
	}
	
	@GetMapping("/hotels")
	public ResponseEntity<ResponseStructure<Hotels>> getAllHotels(Hotels hotels){
		return hotelService.getAllHotel();
	}
	
	@GetMapping("/hotels/{id}")
	public ResponseEntity<ResponseStructure<Hotels>> getHotelsById(@PathVariable int id) {
		return hotelService.getHotelById(id);
	}
	
	@PutMapping("/hotels/{id}")
	public ResponseEntity<ResponseStructure<Hotels>> updateHotel(@PathVariable int id, @RequestBody Hotels hotel)
	{
		return hotelService.updateHotel(id, hotel);
	}
}
