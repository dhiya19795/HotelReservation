package com.ty.HotelReservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.HotelReservation.dto.Rooms;

public interface RoomRepo extends JpaRepository<Rooms, Integer>{

}
