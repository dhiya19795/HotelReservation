package com.ty.HotelReservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.HotelReservation.dto.Users;

public interface UserRepo extends JpaRepository<Users, Integer> {

}
