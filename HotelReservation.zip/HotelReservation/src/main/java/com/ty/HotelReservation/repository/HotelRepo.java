package com.ty.HotelReservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.HotelReservation.dto.Hotels;

public interface HotelRepo extends JpaRepository<Hotels, Integer> {

}
