package com.ty.HotelReservation.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ty.HotelReservation.dto.Hotels;
import com.ty.HotelReservation.repository.HotelRepo;

@Repository
public class HotelDao {
	@Autowired
	private HotelRepo hotelRepo;

	public Hotels saveHotel(Hotels hotels) {
		return hotelRepo.save(hotels);
	}

	public List<Hotels> getAllHotels()
	{
		return hotelRepo.findAll();
	}

	public Hotels getHotelById(int id)
	{
		Optional<Hotels> optional = hotelRepo.findById(id);
		if(optional.isPresent()) {
			Hotels hotels = optional.get();
			return hotels;
		}
		else {
			return null;
		}
	}

	public Hotels updateHotel(int id,Hotels hotel) {

		Optional<Hotels> optional = hotelRepo.findById(id);
		if(optional.isPresent()) {
			Hotels hotels = optional.get();
			hotels.setId(id);
			return hotelRepo.save(hotel);
		}
		else {
			return null;
		}
	}


}
