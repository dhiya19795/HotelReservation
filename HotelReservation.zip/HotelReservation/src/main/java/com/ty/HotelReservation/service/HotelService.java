package com.ty.HotelReservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.HotelReservation.dao.HotelDao;
import com.ty.HotelReservation.dto.Hotels;
import com.ty.HotelReservation.exception.DetailsNotFoundException;
import com.ty.HotelReservation.util.ResponseStructure;


@Service
public class HotelService {
	@Autowired
	HotelDao hotelDao;

	public ResponseEntity<ResponseStructure<Hotels>> saveHotel(Hotels hotel){
		Hotels hotels = hotelDao.saveHotel(hotel);
		ResponseStructure<Hotels> structure = new ResponseStructure<Hotels>();
		structure.setMessage("Data Saved Successfully");
		structure.setHttpStatus(HttpStatus.CREATED.value());
		structure.setData(hotels);
		return new ResponseEntity<ResponseStructure<Hotels>>(structure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Hotels>> getAllHotel(){
		List<Hotels> hotels = hotelDao.getAllHotels();
		ResponseStructure<Hotels> structure = new ResponseStructure<Hotels>();
		structure.setMessage("Data Fetched Successfully");
		structure.setHttpStatus(HttpStatus.FOUND.value());
		structure.setData(hotels);
		return new ResponseEntity<ResponseStructure<Hotels>>(structure,HttpStatus.FOUND);
	}
	public ResponseEntity<ResponseStructure<Hotels>> getHotelById(int id){
		Hotels hotels = hotelDao.getHotelById(id);
		if (hotels!=null) {

			ResponseStructure<Hotels> structure = new ResponseStructure<Hotels>();
			structure.setMessage("Data Fetched Successfully");
			structure.setHttpStatus(HttpStatus.FOUND.value());
			structure.setData(hotels);
			return new ResponseEntity<ResponseStructure<Hotels>>(structure,HttpStatus.FOUND);

		}
		else {
			throw new DetailsNotFoundException("Failed to load data");
		}

	}
	public ResponseEntity<ResponseStructure<Hotels>> updateHotel(int id, Hotels hotel) {
		Hotels hotels = hotelDao.updateHotel(id, hotel);
		if (hotels != null) {
			ResponseStructure<Hotels> structure = new ResponseStructure<Hotels>();
			structure.setMessage("Data Updated successfully");
			structure.setHttpStatus(HttpStatus.OK.value());
			structure.setData(hotels);
			return new ResponseEntity<ResponseStructure<Hotels>>(structure, HttpStatus.OK);
		} else {
			throw new DetailsNotFoundException("Sorry failed to Update the data");

		}

	}







}
