package com.ty.HotelReservation.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ty.HotelReservation.dto.Users;
import com.ty.HotelReservation.repository.UserRepo;

@Repository
public class UserDao {

	@Autowired
	private UserRepo userRepo;

	public Users saveUser(Users users) {
		return userRepo.save(users);
	}

	public List<Users> getAllUsers()
	{
		return userRepo.findAll();
	}

	public Users getUserById(int id) {
		Optional<Users> optional = userRepo.findById(id);
		if (optional.isPresent()) {
			Users users = optional.get();
			return users;
		}
		else {
			return null;
		}
	}

	public Users updateUsers (int id, Users user) {
		Optional<Users> optional = userRepo.findById(id);
		if (optional.isPresent()) {
			Users users = optional.get();
			users.setId(id);
			return userRepo.save(user);

		}
		else {
			return null;
		}
	}
	public Users deleteUser(int id) {
		Optional<Users> optional = userRepo.findById(id);
		if(optional.isPresent()) {
			Users users = optional.get();
			userRepo.delete(users);
			return users;
		}
		else {
			return null;
		}
	}

}
