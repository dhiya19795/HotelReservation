package com.ty.HotelReservation.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ty.HotelReservation.dto.Rooms;
import com.ty.HotelReservation.dto.Users;
import com.ty.HotelReservation.repository.RoomRepo;
import com.ty.HotelReservation.repository.UserRepo;

@Repository
public class RoomDao {

	@Autowired
	private RoomRepo roomRepo;

	@Autowired
	private UserRepo userRepo;

	public Rooms saveRooms(Rooms rooms) {
		return roomRepo.save(rooms);
	}

	public List<Rooms> getAllRooms(){
		return roomRepo.findAll();
	}

	public Rooms getRoomsById(int id) {
		Optional<Rooms> optional = roomRepo.findById(id);
		if (optional.isPresent()) {
			Rooms rooms = optional.get();
			return rooms;
		}
		else {
			return null;
		}

	}

	public Rooms updateRoom(int id, Rooms room) {
		Optional<Rooms> optional = roomRepo.findById(id);
		if (optional.isPresent()) {
			Rooms rooms = optional.get();
			rooms.setId(id);
			return roomRepo.save(room);
		}
		else {
			return null;
		}
	}

	public Rooms reserveRoom(int roomId,int userId)
	{
		Optional<Rooms> optionalRoom = roomRepo.findById(roomId);
		if (optionalRoom.isPresent()) {
			Rooms rooms = optionalRoom.get();
			Optional<Users> users = userRepo.findById(userId);
			if(users.isPresent())
			{
				Users user = users.get();
				if(rooms!=null &user!=null & !rooms.isAvailable())
				{
					rooms.setAvailable(true);
					rooms.setTakenBy(user);
					return roomRepo.save(rooms);
				}
			}
		}
		return null;

	}

	public Rooms vacateRoom(int roomId)
	{
		Optional<Rooms> optional = roomRepo.findById(roomId);
		if (optional.isPresent()) {
			Rooms rooms = optional.get();
			if(rooms!=null && rooms.isAvailable())
			{
				rooms.setAvailable(false);
				rooms.setTakenBy(null);
				return roomRepo.save(rooms);
			}

		}
		return null;
	}


}
