package com.ty.HotelReservation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ty.HotelReservation.dto.Rooms;
import com.ty.HotelReservation.service.RoomService;
import com.ty.HotelReservation.util.ResponseStructure;

@RestController
public class RoomController {

	@Autowired
	RoomService roomService;

	@PostMapping("/rooms")
	public ResponseEntity<ResponseStructure<Rooms>> saveRooms(@RequestBody Rooms room)
	{
		return roomService.saveRooms(room);
	}

	@GetMapping("/rooms")
	public ResponseEntity<ResponseStructure<Rooms>> getAllRooms(Rooms rooms){
		return roomService.getAllRooms();
	}

	@GetMapping("/rooms/{id}")
	public ResponseEntity<ResponseStructure<Rooms>> getRoomsById(@PathVariable int id){
		return roomService.getRoomsById(id);
	}

	@PutMapping("/rooms/{id}")
	public ResponseEntity<ResponseStructure<Rooms>> updateRooms(@PathVariable int id, @RequestBody Rooms rooms){
		return roomService.updateRooms(id, rooms);
	}
	
	@PostMapping("/rooms/{roomId}/{userId}")
	public ResponseEntity<ResponseStructure<Rooms>> reserveRoom(@PathVariable int roomId, @PathVariable int userId)
	{
		return roomService.reserveRoom(roomId, userId);
	}
	@PostMapping("/rooms/{roomId}")
	public ResponseEntity<ResponseStructure<Rooms>> vacateRoom(@PathVariable int roomId)
	{
		return roomService.VacateRoom(roomId);
	}
	


}
