package com.ty.HotelReservation.exception;

public class DetailsNotFoundException extends RuntimeException {
	
	private String message;

	public DetailsNotFoundException(String message) {
		super();
		this.message = message;
	}
	
	


}
