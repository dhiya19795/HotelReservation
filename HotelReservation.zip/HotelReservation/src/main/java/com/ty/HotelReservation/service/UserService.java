package com.ty.HotelReservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.HotelReservation.dao.UserDao;
import com.ty.HotelReservation.dto.Users;
import com.ty.HotelReservation.exception.DetailsNotFoundException;
import com.ty.HotelReservation.util.ResponseStructure;

@Service
public class UserService {

	@Autowired
	UserDao userDao;

	public ResponseEntity<ResponseStructure<Users>> saveUsers(Users users){
		Users user = userDao.saveUser(users);
		ResponseStructure<Users> structure = new ResponseStructure<Users>();
		structure.setMessage("Data Saved Successfully");
		structure.setHttpStatus(HttpStatus.CREATED.value());
		structure.setData(user);
		return new ResponseEntity<ResponseStructure<Users>>(structure,HttpStatus.CREATED);
	}
	public ResponseEntity<ResponseStructure<Users>> getAllUsers(){
		List<Users> users = userDao.getAllUsers();
		ResponseStructure<Users> structure = new ResponseStructure<Users>();
		structure.setMessage("Data Fetched Successfully");
		structure.setHttpStatus(HttpStatus.FOUND.value());
		structure.setData(users);
		return new ResponseEntity<ResponseStructure<Users>>(structure,HttpStatus.FOUND);
	}
	public ResponseEntity<ResponseStructure<Users>> getUsersById(int id){
		Users users = userDao.getUserById(id);
		if (users!=null) {

			ResponseStructure<Users> structure = new ResponseStructure<Users>();
			structure.setMessage("Data Fetched Successfully");
			structure.setHttpStatus(HttpStatus.FOUND.value());
			structure.setData(users);
			return new ResponseEntity<ResponseStructure<Users>>(structure,HttpStatus.FOUND);

		}
		else {
			throw new DetailsNotFoundException("CheckDetails");
		}

	}
	public ResponseEntity<ResponseStructure<Users>> updateUsers(int id, Users users) {
		Users Userss = userDao.updateUsers(id, users);
		if (Userss != null) {
			ResponseStructure<Users> structure = new ResponseStructure<Users>();
			structure.setMessage("Data Updated successfully");
			structure.setHttpStatus(HttpStatus.OK.value());
			structure.setData(Userss);
			return new ResponseEntity<ResponseStructure<Users>>(structure, HttpStatus.OK);
		} else {
			throw new DetailsNotFoundException("CheckDetails");

		}	
	}
	public ResponseEntity<ResponseStructure<Users>> deleteUsers(int id){
		Users users = userDao.deleteUser(id);
		if (users!=null) {

			ResponseStructure<Users> structure = new ResponseStructure<Users>();
			structure.setMessage("Data Deleted Successfully");
			structure.setHttpStatus(HttpStatus.FOUND.value());
			structure.setData(users);
			return new ResponseEntity<ResponseStructure<Users>>(structure,HttpStatus.FOUND);

		}
		else {
			throw new DetailsNotFoundException("CheckDetails");
		}

	}
}
